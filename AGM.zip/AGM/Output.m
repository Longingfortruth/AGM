clear;close all;clc
%Copyright in this document is owned by 415 laboratory
X0=Input;%you can full in your data in Input.m
nf=3;% number of forecast
Model_name='AEGM';% eight models you can choose;please fill in one model's name from 'EGM','DGM','ODGM','EDGM','AEGM','ADGM','AODGM' and 'AEDGM'
[MAPE,X0F]=Get_Model_details(Model_name,X0,nf);

%display the results
disp('MAPE��')
disp(MAPE);
disp('fitting and forecast results��')
disp(X0F);
