function X0=f5(n,ai)
X0=zeros(1,n);
X0(1)=1;
for i=2:n
       error=trnd(ai);
    X0(i)=X0(i-1)+i+error;
     while X0(i)<=0
        X0(i)=X0(i)+1;
    end
end
end
