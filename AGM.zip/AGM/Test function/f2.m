function X0  = f2(n,a)
% x(k)=a*(k-1)+1  
X0(1)=1;
for i=2:n
    X0(i)=a*(i-1)+1;
end
end