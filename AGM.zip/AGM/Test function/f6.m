function X0  = f6( n,ai )
% x(k)=a*(k-1)+1 
X0=zeros(1,n);
X0(1)=1;
for i=2:n
    while X0(i)<=0
        a=normrnd(1,ai);
        X0(i)=a*(i-1)+1;
    end
end
end