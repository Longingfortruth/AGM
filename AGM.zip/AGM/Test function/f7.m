function X0  = f7( n,ai )
% x(k)=a*(k-1)+1 
X0=zeros(1,n);
X0(1)=1;
for i=2:n
    while X0(i)<=0
        a=1.1;
        error=normrnd(0,ai);
        X0(i)=a*X0(i-1)+error;
    end
end
end