function [MAPE,X0F]=AODGM(w,X0,nf)

n=numel(X0);
w;           %��ʾ���� X1(k)=w*X0(k-1)+X0(k)
Xw(1)=X0(1);
for i=2:n
    Xw(i)=w*X0(i-1)+X0(i);
end
for i=1:n-1
    B(i,1)=-Xw(i+1);
    B(i,2)=1;
    Y(i,1)=Xw(i+1)-Xw(i);
end
P=inv(B'*B)*B'*Y;
a=P(1);
b=P(2);
XwF(1)=X0(1);
for i=2:n+nf
  XwF(i)=(XwF(1)-b/a)*((1/(1+a))^(i-1))+b/a;
end
X0F(1)=X0(1);
for i=2:n+nf
  X0F(i)=XwF(i)-w*X0F(i-1);
end
for i=2:n
    mape(i)=abs(X0F(i)-X0(i))/X0(i);
end
MAPE=mean(mape(2:n));

end