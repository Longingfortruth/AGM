function [MAPE,X0F]=ODGM(X0,nf)
n=numel(X0);
X1(1)=X0(1);
for i=2:n
    X1(i)=X1(i-1)+X0(i);
end
for i=1:n-1
    B(i,1)=-X1(i+1);
    B(i,2)=1;
    Y(i,1)=X0(i+1);
end
P=inv(B'*B)*B'*Y;
a=P(1);
b=P(2);
X1F(1)=X0(1);
for i=2:n+nf
  X1F(i)=(X1F(1)-b/a)*((1/(1+a))^(i-1))+b/a;
end
for i=2:n+nf
  X0F(i)=X1F(i)-X1F(i-1);
end
X0F(1)=X0(1);
for i=2:n
    e(i)=abs(X0F(i)-X0(i))/X0(i);
end
MAPE=mean(e(2:n));
end