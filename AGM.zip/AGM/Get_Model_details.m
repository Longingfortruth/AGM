function [MAPE,X0F] = Get_Model_details( F,X0,nf)
%GET_MODEL_DETAILS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
switch F  
    case 'EGM'
        [MAPE,X0F]=EGM(X0,nf);
    case 'DGM'
        [MAPE,X0F]=DGM(X0,nf);
    case 'ODGM'
        [MAPE,X0F]=ODGM(X0,nf);
    case 'EDGM'
        [MAPE,X0F]=EDGM(X0,nf);
    case 'AEGM'
        fobj=@AEGM;
        [MAPE,X0F]=PSO_AEGM(X0,fobj,nf);
    case 'ADGM'
        fobj=@ADGM;
        [MAPE,X0F]=PSO_ADGM(X0,fobj,nf);
    case 'AODGM'
        fobj=@AODGM;
        [MAPE,X0F]=PSO_AODGM(X0,fobj,nf);
    case 'AEDGM'
        fobj=@AEDGM;
        [MAPE,X0F]=PSO_AEDGM(X0,fobj,nf);
end
end

function  [MAPE,X0F]=PSO_AEGM(X0,fobj,nf)
    [gBest,pmin]=PSO(X0,fobj,nf);
    [MAPE,X0F]=AEGM(gBest,X0,nf);
end
function  [MAPE,X0F]=PSO_ADGM(X0,fobj,nf)
    [gBest,pmin]=PSO(X0,fobj,nf);
    [MAPE,X0F]=ADGM(gBest,X0,nf);
end
function  [MAPE,X0F]=PSO_AODGM(X0,fobj,nf)
    [gBest,pmin]=PSO(X0,fobj,nf);
    [MAPE,X0F]=AODGM(gBest,X0,nf);
end
function  [MAPE,X0F]=PSO_AEDGM(X0,fobj,nf)
    [gBest,pmin]=PSO(X0,fobj,nf);
    [MAPE,X0F]=AEDGM(gBest,X0,nf);
end

